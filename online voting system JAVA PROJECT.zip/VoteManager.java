import java.util.*;
import java.nio.file.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

public class VoteManager {
    private static final String VOTES_FILE = "votes.dat";
    private Map<String, String> votes = new HashMap<>(); // email -> encrypted vote
    private SecretKey secretKey;

    public VoteManager() {
        try {
            // Use a fixed key for simplicity, but in real projects generate & store securely
            byte[] keyBytes = "1234567890123456".getBytes(); // 16 bytes key
            secretKey = new SecretKeySpec(keyBytes, "AES");
        } catch (Exception e) {
            e.printStackTrace();
        }
        loadVotes();
    }

    public boolean hasVoted(String email) {
        return votes.containsKey(email);
    }

    public void vote(String email, String candidate) {
        String encrypted = encrypt(candidate);
        votes.put(email, encrypted);
        saveVotes();
    }

    private void loadVotes() {
        try {
            List<String> lines = Files.readAllLines(Paths.get(VOTES_FILE));
            for (String line : lines) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    votes.put(parts[0], parts[1]);
                }
            }
        } catch (Exception e) {
            // file not found or other issue - start fresh
        }
    }

    private void saveVotes() {
        try {
            List<String> lines = new ArrayList<>();
            for (Map.Entry<String, String> e : votes.entrySet()) {
                lines.add(e.getKey() + ":" + e.getValue());
            }
            Files.write(Paths.get(VOTES_FILE), lines);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String encrypt(String data) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encrypted = cipher.doFinal(data.getBytes());
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}