import java.util.*;

public class VotingSystem {
    private Scanner scanner = new Scanner(System.in);
    private UserManager userManager = new UserManager();
    private VoteManager voteManager = new VoteManager();
    private AdminLogger adminLogger = new AdminLogger();

    public void run() {
        System.out.println("Welcome to the Java Online Voting System!");
        while (true) {
            System.out.println("1. Register\n2. Login\n3. Exit");
            String choice = scanner.nextLine();
            switch(choice) {
                case "1": registerUser(); break;
                case "2": loginUser(); break;
                case "3": System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid choice"); break;
            }
        }
    }

    private void registerUser() {
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        if (userManager.register(email, password)) {
            System.out.println("Registered successfully.");
            adminLogger.log("User registered: " + email);
        } else {
            System.out.println("Registration failed. User may already exist.");
        }
    }

    private void loginUser() {
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        if (!userManager.authenticate(email, password)) {
            System.out.println("Invalid credentials.");
            return;
        }
        // Simulate OTP
        String otp = OTPUtil.generateOTP();
        System.out.println("Your OTP is: " + otp);
        System.out.print("Enter OTP: ");
        String enteredOtp = scanner.nextLine();
        if (!otp.equals(enteredOtp)) {
            System.out.println("Invalid OTP.");
            return;
        }
        if (voteManager.hasVoted(email)) {
            System.out.println("You have already voted. Cannot vote again.");
            return;
        }
        System.out.print("Enter candidate to vote for: ");
        String candidate = scanner.nextLine();
        voteManager.vote(email, candidate);
        System.out.println("Thank you for voting!");
        adminLogger.log("User voted: " + email + " for " + candidate);
    }
}