import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        VotingSystem vs = new VotingSystem();
        vs.run();
    }
}