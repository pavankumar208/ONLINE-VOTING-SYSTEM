import java.util.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UserManager {
    private static final String USERS_FILE = "users.dat";
    private Map<String, String> users = new HashMap<>(); // email -> hashed password

    public UserManager() {
        loadUsers();
    }

    public boolean register(String email, String password) {
        if (users.containsKey(email)) return false;
        users.put(email, hash(password));
        saveUsers();
        return true;
    }

    public boolean authenticate(String email, String password) {
        if (!users.containsKey(email)) return false;
        String storedHash = users.get(email);
        return storedHash.equals(hash(password));
    }

    private void loadUsers() {
        try {
            List<String> lines = Files.readAllLines(Paths.get(USERS_FILE));
            for (String line : lines) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    users.put(parts[0], parts[1]);
                }
            }
        } catch (Exception e) {
            // file not found or other issue - start fresh
        }
    }

    private void saveUsers() {
        try {
            List<String> lines = new ArrayList<>();
            for (Map.Entry<String, String> e : users.entrySet()) {
                lines.add(e.getKey() + ":" + e.getValue());
            }
            Files.write(Paths.get(USERS_FILE), lines);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String hash(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashed = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashed) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}