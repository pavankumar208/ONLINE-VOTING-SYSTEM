import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AdminLogger {
    private static final String LOG_FILE = "admin.log";

    public void log(String action) {
        try(FileWriter fw = new FileWriter(LOG_FILE, true)) {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            fw.write(timestamp + " - " + action + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}